import numpy as np
import pandas as pd
from sklearn.svm import SVR
from sklearn.model_selection import train_test_split, KFold

hyperparameter_name = "C"
hp_value = [1024, 2048, 4096]

train_df = pd.read_excel("Train_data_for_model_validation.xlsx")
val_df = pd.read_excel("Val_data_for_model_validation.xlsx")

index_tags = ["cluster"]
label_tags = ["FEPA"]

X_train = train_df.drop(columns=index_tags+label_tags)
y_train = np.array(train_df["FEPA"])
X_train = X_train.values


X_val = val_df.drop(columns=index_tags+label_tags)
y_val = np.array(val_df["FEPA"])
X_val = X_val.values
#y_dict = y_dict.values


#X_test = test_df.drop(columns=index_tags+label_tags)
#y_test = np.array(test_df["lgk1"])

for num in hp_value:
    reg = SVR(C=num)
    reg = reg.fit(X_train, y_train)
    y_train_pred = reg.predict(X_train)
    y_val_pred = reg.predict(X_val)
    val_MAE = np.mean(np.absolute(y_val_pred - y_val))
    #y_test_pred = reg.predict(X_test)

    #train_MAE = np.mean(np.absolute(y_train_pred - y_train))
    #test_MAE = np.mean(np.absolute(y_test_pred - y_test))

    print(f"{num} {hyperparameter_name} Validation MAE:{val_MAE}")
    
