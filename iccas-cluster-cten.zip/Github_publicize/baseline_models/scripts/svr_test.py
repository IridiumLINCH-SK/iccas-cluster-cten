import numpy as np
import pandas as pd
from sklearn.svm import SVR
from sklearn.model_selection import train_test_split, KFold

#hyperparameter_name = "min_samples_leaf"
#hp_value = [1, 2]

train_df = pd.read_excel("Train_data_for_model_validation.xlsx")
test_df = pd.read_excel("Test_data_for_model_validation.xlsx")

index_tags = ["cluster"]
label_tags = ["FEPA"]

X_train = train_df.drop(columns=index_tags+label_tags)
y_train = np.array(train_df["FEPA"])
X_train = X_train.values
#y_dict = y_dict.values

#kfold = KFold(n_splits=8, shuffle=True, random_state=0)
#kfold.get_n_splits(X_dict)

X_test = test_df.drop(columns=index_tags+label_tags)
y_test = np.array(test_df["FEPA"])


reg = SVR(C=1024)
reg = reg.fit(X_train, y_train)
y_train_pred = reg.predict(X_train)
y_test_pred = reg.predict(X_test)


train_MAE = np.mean(np.absolute(y_train_pred - y_train))
test_MAE = np.mean(np.absolute(y_test_pred - y_test))

print(f"Train MAE: {train_MAE}, Test MAE: {test_MAE}")

y_train_pred = pd.DataFrame(y_train_pred)
y_test_pred = pd.DataFrame(y_test_pred)
y_train_pred.to_excel("y_train_pred.xlsx")
y_test_pred.to_excel("y_test_pred.xlsx")
