import torch
import time
import torch.nn as nn
import torch.nn.init as init
import torch.optim as optim
import numpy as np
import pandas as pd
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import KFold

train_df = pd.read_excel("Train_data_for_model_validation.xlsx")
y_train = train_df['FEPA']
X_train = train_df.drop(columns=['cluster', 'FEPA'])
input_nodes = len(X_train.columns)
device = torch.device("cuda")
#dloader = DataLoader()

X_train = torch.tensor(X_train.values, dtype=torch.float32).to(device)
y_train = torch.tensor(y_train.values, dtype=torch.float32).to(device)
#print(input_nodes)
h1 = 512
h2 = 256
h3 = 128
h4 = 64
epoch = 800
lr = 0.001
bsz = 16

class MLP(nn.Module):
    def __init__(self, input_nodes, h1, h2, h3, h4, output_nodes=1):
        super().__init__()
        self.linear1 = nn.Linear(input_nodes, h1)
        self.linear2 = nn.Linear(h1, h2)
        self.linear3 = nn.Linear(h2, h3)
        self.linear4 = nn.Linear(h3, h4)
        self.linear5 = nn.Linear(h4, 1)
        self.relu = nn.ReLU()
        self.tanh = nn.Tanh()
    def forward(self, X):
        out = self.linear5(self.tanh(self.linear4(self.tanh(self.linear3(self.tanh(self.linear2(self.tanh(self.linear1(X)))))))))
        return out.squeeze(-1)

class TRAIN(Dataset):
    def __init__(self, X_train, y_train):
        self.X = X_train
        self.y = y_train
    def __getitem__(self, idx):
        return (self.X[idx], self.y[idx])
    def __len__(self):
        return len(self.X)

dloader = DataLoader(TRAIN(X_train, y_train), batch_size=bsz)
net = MLP(input_nodes, h1, h2, h3, h4)
net = net.to(device)
for param in net.parameters():
    init.normal_(param, mean=0, std=0.01)

loss = nn.MSELoss()
optimizer = optim.Adam(net.parameters(), lr=lr)


test_df = pd.read_excel("Val_data_for_model_validation.xlsx")
y_test = test_df['FEPA']
X_test = test_df.drop(columns=['cluster', 'FEPA'])

X_test = torch.tensor(X_test.values, dtype=torch.float32).to(device)
y_test = torch.tensor(y_test.values, dtype=torch.float32).to(device)


for _ in range(epoch):
    for data in dloader:
        X_bat, y_bat = data
        y_pred = net.forward(X_bat)
        ll = loss(y_pred, y_bat)
        optimizer.zero_grad()  # 清零梯度
        ll.backward()  # 反向传播，计算梯度
        optimizer.step()  # 更新模型参数

    print('epoch: ', _ + 1, 'loss: ', ll.item())
    with torch.no_grad():
        y_test_pred = net.forward(X_test)
        y_train_pred = net.forward(X_train)

    train_MAE = torch.mean(torch.abs(y_train_pred - y_train))
    test_MAE = torch.mean(torch.abs(y_test_pred - y_test))

    print(f"Train MAE: {train_MAE}, Val MAE: {test_MAE}")
